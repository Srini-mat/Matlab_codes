%%Explicit Method 
%% Uniform Initial Condition
clear 
clc
x = 0.1;  % Only equal interval step sizes are to be given
m = round(1/x);
beta = 0.7;   %input beta Value ; alpha =1
del_t = beta*(x^2);  % time step size calculation
del_t = round(1/del_t) +1;
X = 0:x:1;
t0 = [20*ones(m,1); 100];  %Initial and Boundary conditions

t = zeros(m+1,1);
t(1) = t0(1); t(end) = t0(end);
 

for n = 1:del_t
for j = 2:m
t(j)  = beta*(t0(j+1) + t0(j-1)) +(1 -(2*beta))*t0(j);
r(j) = t(j) - t0(j);

end
t0 = t;
res(n) = norm(r);
end
figure
plot(X,t);
xlabel('Length in x direction');
ylabel('Temperature in Celcius');
title('Explicit solution with Constant temperature Initial condition');
figure 
plot(1:del_t,res);
xlabel('Time steps');
ylabel('Residue');
title('Residue vs time (Explicit solution with constant temperature IC');
