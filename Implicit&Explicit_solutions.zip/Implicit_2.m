%% Implicit solution for Constant Temperature Initial Conditions
clear
clc
x = 0.1;
m = round(1/x);
beta = 0.3;   %input beta Value ; alpha =1
delt = beta*(x^2);  % time step size calculation
delt = round(1/delt) +1;
a = 1+ 2*beta;
b = - beta;
Coeff = diag(a*ones(1,m-1)) + diag(b*ones(1,m-2),1) + diag(b*ones(1,m-2),-1);
tn = ones(m-1,1)*20;  %temperature at n time
rhs = ones(m-1,1)* 20; % Intitial Condition
rhs(1) = rhs(1) - b*20; % boundary condtions
rhs(end) = rhs(end) - b*100;
for n = 1:delt
mat = [Coeff rhs];  % joint matrix of LHS and RHS
mat(1,:) = mat(1,:)/a ;
for i = 2:m-1
mat(i,:) = (mat(i,:) -b*mat(i-1,:))/(a - b*mat(i-1,i)); % Thomas Algorithm
end
t = zeros(m-1,1); residue = zeros(m-1,1);
t(end) = mat(end,end); residue(end) = t(end) - tn(end);
for i = 1:m-2                 % Temperature at n+1 time 
t(end-i) = mat(end-i,end) - mat(end-i,end-i)*t(end-i+1);  %sweep from bottom
residue(end-i) = t(end-i) - tn(end-i);
end
tn = t;
RES(n) = norm(residue);
rhs = t;
rhs(1) = rhs(1) - b*20; % boundary condtion
rhs(end) = rhs(end) - b*100;
end
temp = [20 t' 100];
figure
plot(0:x:1, temp);
xlabel('Length in x direction');
ylabel('Temperature in Celcius');
title('Implicit solution with constant initial conditions'); 

figure
plot(1:delt,RES);
xlabel('Time steps');
ylabel('Residue');
title('Residue variation: Implicit solution(constant temperature)');


